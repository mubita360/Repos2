﻿namespace SMSystem.Forms
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            this.label3 = new System.Windows.Forms.Label();
            this.PW = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.UN = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Pan = new MetroFramework.Controls.MetroPanel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.plzClick = new MetroFramework.Controls.MetroLabel();
            this.LgnBtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.MiniBtn = new System.Windows.Forms.Button();
            this.check_Show = new System.Windows.Forms.CheckBox();
            this.lblShow = new System.Windows.Forms.Label();
            this.Pan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(153, 323);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Enter &User Name and &Password";
            // 
            // PW
            // 
            this.PW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PW.Location = new System.Drawing.Point(95, 376);
            this.PW.Name = "PW";
            this.PW.Size = new System.Drawing.Size(244, 20);
            this.PW.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(7, 378);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 19);
            this.label2.TabIndex = 9;
            this.label2.Text = "Password:";
            // 
            // UN
            // 
            this.UN.BackColor = System.Drawing.SystemColors.Window;
            this.UN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.UN.Location = new System.Drawing.Point(95, 348);
            this.UN.Name = "UN";
            this.UN.Size = new System.Drawing.Size(244, 20);
            this.UN.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(7, 350);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 19);
            this.label1.TabIndex = 7;
            this.label1.Text = "User Name:";
            // 
            // Pan
            // 
            this.Pan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Pan.Controls.Add(this.pictureBox2);
            this.Pan.Controls.Add(this.metroLabel1);
            this.Pan.HorizontalScrollbarBarColor = true;
            this.Pan.HorizontalScrollbarHighlightOnWheel = false;
            this.Pan.HorizontalScrollbarSize = 10;
            this.Pan.Location = new System.Drawing.Point(209, -5);
            this.Pan.Name = "Pan";
            this.Pan.Size = new System.Drawing.Size(179, 39);
            this.Pan.Style = MetroFramework.MetroColorStyle.Black;
            this.Pan.TabIndex = 4;
            this.Pan.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Pan.VerticalScrollbarBarColor = true;
            this.Pan.VerticalScrollbarHighlightOnWheel = false;
            this.Pan.VerticalScrollbarSize = 10;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(80, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(96, 34);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            this.pictureBox2.MouseLeave += new System.EventHandler(this.plzClik);
            this.pictureBox2.MouseHover += new System.EventHandler(this.plzCli);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel1.ForeColor = System.Drawing.Color.White;
            this.metroLabel1.Location = new System.Drawing.Point(4, 5);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(69, 15);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Powered By:";
            this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // ExitBtn
            // 
            this.ExitBtn.BackColor = System.Drawing.Color.Black;
            this.ExitBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ExitBtn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitBtn.ForeColor = System.Drawing.Color.White;
            this.ExitBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ExitBtn.Location = new System.Drawing.Point(277, 425);
            this.ExitBtn.Margin = new System.Windows.Forms.Padding(1);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(58, 23);
            this.ExitBtn.TabIndex = 3;
            this.ExitBtn.Text = "&Exit";
            this.ExitBtn.UseVisualStyleBackColor = false;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // plzClick
            // 
            this.plzClick.AutoSize = true;
            this.plzClick.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.plzClick.ForeColor = System.Drawing.Color.White;
            this.plzClick.Location = new System.Drawing.Point(239, 34);
            this.plzClick.Name = "plzClick";
            this.plzClick.Size = new System.Drawing.Size(0, 0);
            this.plzClick.TabIndex = 17;
            this.plzClick.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // LgnBtn
            // 
            this.LgnBtn.BackColor = System.Drawing.Color.Black;
            this.LgnBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.LgnBtn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LgnBtn.ForeColor = System.Drawing.Color.White;
            this.LgnBtn.Image = ((System.Drawing.Image)(resources.GetObject("LgnBtn.Image")));
            this.LgnBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LgnBtn.Location = new System.Drawing.Point(203, 425);
            this.LgnBtn.Margin = new System.Windows.Forms.Padding(1);
            this.LgnBtn.Name = "LgnBtn";
            this.LgnBtn.Size = new System.Drawing.Size(66, 23);
            this.LgnBtn.TabIndex = 2;
            this.LgnBtn.Text = "&Login";
            this.LgnBtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.LgnBtn.UseVisualStyleBackColor = false;
            this.LgnBtn.Click += new System.EventHandler(this.LgnBtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(87, 105);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(199, 204);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // MiniBtn
            // 
            this.MiniBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MiniBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.MiniBtn.Image = ((System.Drawing.Image)(resources.GetObject("MiniBtn.Image")));
            this.MiniBtn.Location = new System.Drawing.Point(2, 1);
            this.MiniBtn.Margin = new System.Windows.Forms.Padding(1);
            this.MiniBtn.Name = "MiniBtn";
            this.MiniBtn.Size = new System.Drawing.Size(25, 28);
            this.MiniBtn.TabIndex = 18;
            this.MiniBtn.UseVisualStyleBackColor = true;
            this.MiniBtn.Click += new System.EventHandler(this.MiniBtn_Click);
            // 
            // check_Show
            // 
            this.check_Show.AutoSize = true;
            this.check_Show.Location = new System.Drawing.Point(346, 382);
            this.check_Show.Name = "check_Show";
            this.check_Show.Size = new System.Drawing.Size(15, 14);
            this.check_Show.TabIndex = 19;
            this.check_Show.UseVisualStyleBackColor = true;
            this.check_Show.CheckedChanged += new System.EventHandler(this.check_Show_CheckedChanged);
            this.check_Show.MouseLeave += new System.EventHandler(this.Dispo);
            this.check_Show.MouseHover += new System.EventHandler(this.Jiren);
            // 
            // lblShow
            // 
            this.lblShow.AutoSize = true;
            this.lblShow.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShow.ForeColor = System.Drawing.Color.White;
            this.lblShow.Location = new System.Drawing.Point(168, 403);
            this.lblShow.Name = "lblShow";
            this.lblShow.Size = new System.Drawing.Size(0, 15);
            this.lblShow.TabIndex = 20;
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 496);
            this.Controls.Add(this.lblShow);
            this.Controls.Add(this.check_Show);
            this.Controls.Add(this.MiniBtn);
            this.Controls.Add(this.plzClick);
            this.Controls.Add(this.LgnBtn);
            this.Controls.Add(this.Pan);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.PW);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.UN);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LoginForm";
            this.Resizable = false;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Style = MetroFramework.MetroColorStyle.Black;
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.TransparencyKey = System.Drawing.Color.OrangeRed;
            this.Load += new System.EventHandler(this.LoginForm_Load);
            this.Pan.ResumeLayout(false);
            this.Pan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox PW;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox UN;
        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroPanel Pan;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button LgnBtn;
        private MetroFramework.Controls.MetroLabel plzClick;
        private System.Windows.Forms.Button MiniBtn;
        private System.Windows.Forms.CheckBox check_Show;
        private System.Windows.Forms.Label lblShow;
    }
}