﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMSystem.Forms
{
    public partial class MainWindow : MetroFramework.Forms.MetroForm
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        
        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MiniBtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void RestWin_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            RestWin.Hide();
            MaxiBtn.Show();
        }

        private void MaxiBtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            MaxiBtn.Hide();
            RestWin.Show();
        }
    }
}
