﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace SMSystem.Forms
{
    public partial class SplashScreen : Form
    {
        public SplashScreen()
        {
            InitializeComponent();
        }
        int incre;
        private void timer1_Tick(object sender, EventArgs e)
        {
            progBar.Value = incre;
            lblload.Text = ("Loading  " + incre + " %");
            incre = incre + 1;
            progBar.Increment(1);
            if(progBar.Value == 100)
            {
                timer1.Stop();
                LoginForm Lf = new LoginForm();
                this.Hide();
                Lf.Show();
            }
        }

        private void SplashScreen_Load(object sender, EventArgs e)
        {
            timer1.Start();

        }
    }
}



