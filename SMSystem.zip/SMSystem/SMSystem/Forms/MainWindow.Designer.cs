﻿namespace SMSystem.Forms
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainWindow));
            this.panel1 = new System.Windows.Forms.Panel();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.MiniBtn = new System.Windows.Forms.Button();
            this.DGV = new System.Windows.Forms.DataGridView();
            this.RestWin = new System.Windows.Forms.Button();
            this.MaxiBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DGV)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panel1.Location = new System.Drawing.Point(0, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(725, 23);
            this.panel1.TabIndex = 4;
            // 
            // ExitBtn
            // 
            this.ExitBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ExitBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ExitBtn.Image = ((System.Drawing.Image)(resources.GetObject("ExitBtn.Image")));
            this.ExitBtn.Location = new System.Drawing.Point(776, 1);
            this.ExitBtn.Margin = new System.Windows.Forms.Padding(1);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(25, 28);
            this.ExitBtn.TabIndex = 3;
            this.ExitBtn.UseVisualStyleBackColor = true;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // MiniBtn
            // 
            this.MiniBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MiniBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.MiniBtn.Image = ((System.Drawing.Image)(resources.GetObject("MiniBtn.Image")));
            this.MiniBtn.Location = new System.Drawing.Point(726, 1);
            this.MiniBtn.Margin = new System.Windows.Forms.Padding(1);
            this.MiniBtn.Name = "MiniBtn";
            this.MiniBtn.Size = new System.Drawing.Size(25, 28);
            this.MiniBtn.TabIndex = 1;
            this.MiniBtn.UseVisualStyleBackColor = true;
            this.MiniBtn.Click += new System.EventHandler(this.MiniBtn_Click);
            // 
            // DGV
            // 
            this.DGV.BackgroundColor = System.Drawing.Color.White;
            this.DGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV.Location = new System.Drawing.Point(23, 63);
            this.DGV.Name = "DGV";
            this.DGV.Size = new System.Drawing.Size(756, 458);
            this.DGV.TabIndex = 5;
            // 
            // RestWin
            // 
            this.RestWin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RestWin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RestWin.Image = ((System.Drawing.Image)(resources.GetObject("RestWin.Image")));
            this.RestWin.Location = new System.Drawing.Point(752, 1);
            this.RestWin.Margin = new System.Windows.Forms.Padding(1);
            this.RestWin.Name = "RestWin";
            this.RestWin.Size = new System.Drawing.Size(25, 28);
            this.RestWin.TabIndex = 6;
            this.RestWin.UseVisualStyleBackColor = true;
            this.RestWin.Click += new System.EventHandler(this.RestWin_Click);
            // 
            // MaxiBtn
            // 
            this.MaxiBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MaxiBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.MaxiBtn.Image = ((System.Drawing.Image)(resources.GetObject("MaxiBtn.Image")));
            this.MaxiBtn.Location = new System.Drawing.Point(752, 1);
            this.MaxiBtn.Margin = new System.Windows.Forms.Padding(1);
            this.MaxiBtn.Name = "MaxiBtn";
            this.MaxiBtn.Size = new System.Drawing.Size(25, 28);
            this.MaxiBtn.TabIndex = 7;
            this.MaxiBtn.UseVisualStyleBackColor = true;
            this.MaxiBtn.Click += new System.EventHandler(this.MaxiBtn_Click);
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(802, 542);
            this.Controls.Add(this.MaxiBtn);
            this.Controls.Add(this.RestWin);
            this.Controls.Add(this.DGV);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.MiniBtn);
            this.Name = "MainWindow";
            this.ShowIcon = false;
            this.Style = MetroFramework.MetroColorStyle.Black;
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            ((System.ComponentModel.ISupportInitialize)(this.DGV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button MiniBtn;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView DGV;
        private System.Windows.Forms.Button RestWin;
        private System.Windows.Forms.Button MaxiBtn;
    }
}