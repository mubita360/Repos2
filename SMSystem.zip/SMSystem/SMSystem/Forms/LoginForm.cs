﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMSystem.Forms
{
    public partial class LoginForm : MetroFramework.Forms.MetroForm
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            
            
            Developers Dev = new Developers();
            Dev.Show();
            this.Hide();

        }

        private void plzCli(object sender, EventArgs e)
        {
            plzClick.Text = ("Please Click Me");
        }

        private void plzClik(object sender, EventArgs e)
        {
            plzClick.Text = ("");
        }

        private void MiniBtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void LgnBtn_Click(object sender, EventArgs e)
        {
            if (UN.Text == "Admin" && PW.Text == "1234")
            {
                this.Hide();
                MainWindow mw = new MainWindow();
                mw.Show();
            }
            else
                MessageBox.Show("Wrong Password or Username", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void Dispo(object sender, EventArgs e)
        {
            lblShow.Text = ("");
        }

        private void Jiren(object sender, EventArgs e)
        {
            lblShow.Text = ("Show/Hide Password");
        }

        private void check_Show_CheckedChanged(object sender, EventArgs e)
        {
            if (check_Show.Checked)
            {
                //show password
                PW.UseSystemPasswordChar = false;
            }
            else
            {
                //Hide Password
                PW.UseSystemPasswordChar = true;
            }
                
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            //give hiding properties to the password
            PW.UseSystemPasswordChar = true;
        }
    }
}
